package com.werockstar.dagger211.data

class UserResponse(val login: String)