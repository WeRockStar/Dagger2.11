package com.werockstar.dagger211.di.module

import dagger.Module

@Module
class ApplicationModule